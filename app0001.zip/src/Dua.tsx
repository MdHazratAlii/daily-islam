import React, { useState } from 'react';
import homeIcon from './assets/home.png';

const Dua: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  const duas = [
    { id: 1, text: 'রাব্বানা আতিনা ফিদ্দুনিয়া হাসানাতাওঁ ওয়া ফিল আখিরাতি হাসানাতাওঁ ওয়া ক্বিনা আযাবান্নার।' },
    { id: 2, text: 'আল্লাহুম্মাগফিরলি ওয়া লিওয়ালিদাইয়া ওয়া লিলমুমিনিনা ইয়াওমা ইয়াকুমুল হিসাব।' },
    { id: 3, text: 'রাব্বিজ্জালনি মুকিমাস সালাতি ওয়া মিন যুররিয়্যাতি।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 4, text: 'রাব্বির হামহুমা কামা রাব্বাইয়ানি সাগিরা।' },
    { id: 5, text: 'আল্লাহুম্মা ইন্নি আসআলুকা ইলমান নাফিআ।' },
  ];

  const filteredDuas = duas.filter((dua) =>
    dua.text.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="dua-page">
        <h1 className="top-title">দোয়া সমূহ</h1>

      {/* Search Bar */}
      <input
        type="text"
        placeholder="দোয়া খুঁজুন..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        className="search-bar"
      />

      {/* Dua List */}
      <ul className="dua-list">
        {filteredDuas.map((dua) => (
          <li key={dua.id}>{dua.text}</li>
        ))}
      </ul>

      {/* Bottom Navigation */}
      <div className="bottom-nav">
        <button onClick={() => window.location.href = '/dua'}>দোয়া</button>
        <button onClick={() => window.location.href = '/'}>
          <img src={homeIcon} alt="Home" className="icon" />
        </button>
        <button onClick={() => window.location.href = '/qna'}>প্রশ্নোত্তর</button>
      </div>
    </div>
  );
};

export default Dua;